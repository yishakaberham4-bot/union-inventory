export default function SalesPosPage() {
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-4">
      <h1 className="text-2xl font-bold text-white">Point of Sale</h1>
      <p className="text-slate-400 text-sm">
        You are signed in as a sales user. POS features can be built here.
      </p>
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-8 text-center text-slate-500">
        Sales terminal ready
      </div>
    </div>
  )
}
